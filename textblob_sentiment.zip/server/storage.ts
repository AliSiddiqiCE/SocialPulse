import fs from 'fs';
import path from 'path';
import { parse } from 'csv-parse/sync';
// @ts-ignore
import fetch from 'node-fetch';
import { SentimentRecord } from './types';

// Initialize global sentiment data if not exists
if (!global.sentimentData) {
  global.sentimentData = [];
}

// Helper to read and parse a CSV file from the public folder
// CSV-only mode: all types are 'any' for demo simplicity
function readCSV(filename: string): any[] {
  try {
  const filePath = path.join(process.cwd(), 'public', filename);
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const rows = parse(fileContent, { columns: true, skip_empty_lines: true });
    
    // For YouTube data, normalize the date field
    if (filename.includes('yt_')) {
      return rows.map((row: any) => {
        // If date is empty, try to extract from title or use a fallback
        if (!row.date && row.title) {
          const dateMatch = row.title.match(/\b\d{4}\b/);
          row.date = dateMatch ? `${dateMatch[0]}-01-01` : new Date().toISOString().split('T')[0];
        }
        return row;
      });
    }
    return rows;
  } catch (error) {
    console.error(`Error reading CSV file ${filename}:`, error);
    return [];
  }
}

function isWithinDateRange(dateStr: string, startDate?: string, endDate?: string): boolean {
  if (!dateStr || (!startDate && !endDate)) return true;
  
  try {
    // Try to parse the date, handling different formats
    let date: Date;
    if (dateStr.includes('T')) {
      date = new Date(dateStr);
    } else {
      // For dates without time, set to start of day
      date = new Date(dateStr + 'T00:00:00');
    }
    
    if (isNaN(date.getTime())) return true; // If date is invalid, include the row
    
    if (startDate) {
      const start = new Date(startDate + 'T00:00:00');
      if (date < start) return false;
    }
    
    if (endDate) {
      const end = new Date(endDate + 'T23:59:59');
      if (date > end) return false;
    }
    
  return true;
  } catch (error) {
    console.error('Error parsing date:', error);
    return true; // If there's an error, include the row
  }
}

// Helper function to calculate engagement score based on platform and data
function calculateEngagementScore(platform: string, data: any[]): string {
  if (!data || data.length === 0) return '0%';
  
  let totalEngagement = 0;
  let totalReach = 0;
  
  switch (platform) {
    case 'tiktok':
      totalEngagement = data.reduce((sum, row) => 
        sum + Number(row.diggCount || 0) + Number(row.shareCount || 0) + Number(row.commentCount || 0), 0);
      totalReach = data.reduce((sum, row) => sum + Number(row.playCount || 0), 0);
      break;
    case 'instagram':
      totalEngagement = data.reduce((sum, row) => 
        sum + Number(row.likesCount || 0) + Number(row.commentsCount || 0), 0);
      totalReach = data.reduce((sum, row) => sum + Number(row.videoViewCount || 0), 0);
      break;
    case 'youtube':
      totalEngagement = data.reduce((sum, row) => 
        sum + Number(row.likes || 0) + Number(row.commentsCount || 0), 0);
      totalReach = data.reduce((sum, row) => sum + Number(row.viewCount || 0), 0);
      break;
    default:
      return '0%';
  }
  
  // Calculate engagement rate: (Total Engagement / Total Reach) * 100
  const engagementRate = totalReach > 0 ? (totalEngagement / totalReach) * 100 : 0;
  return `${engagementRate.toFixed(1)}%`;
}

// Add a new helper to normalize and aggregate posts for all platforms and brands as per the new rules
function aggregatePosts(brandId: number) {
  const posts: any[] = [];

  // --- TIKTOK (Both brands, both sources) ---
  const tiktokFiles = brandId === 1
    ? ['mands_tik_off.csv', 'mands_tik_hash.csv']
    : ['next_tik_off.csv', 'next_tik_hash.csv'];
  for (const file of tiktokFiles) {
    for (const row of readCSV(file)) {
      const likes = Number(row.diggCount || 0);
      const comments = Number(row.commentCount || 0);
      const reach = Number(row.playCount || 0);
      // Only include in engagement rate if all three are present and greater than zero
      const validForEngagementRate = likes > 0 && comments > 0 && reach > 0;
      if (likes || comments) {
        posts.push({
          brandId,
          platform: 'tiktok',
          likes,
          comments,
          reach,
          totalEngagement: likes + comments,
          engagementRate: validForEngagementRate ? (likes + comments) / reach : null,
          date: row.created_time,
          hashtags: row.hashtags || '',
          mentions: row.mentions || '',
        });
      }
    }
  }

  // --- INSTAGRAM ---
  const instaHash = brandId === 1 ? 'mands_insta_hash.csv' : 'next_insta_hash.csv';
  const instaOff = brandId === 1 ? 'mands_insta_off.csv' : 'next_insta_off.csv';
  // OFFICIAL
  for (const row of readCSV(instaOff)) {
    let likes = 0;
    if (brandId === 1) likes = Number(row.likesCount || 0); // M&S: likes from OFF
    const comments = Number(row.commentsCount || 0);
    const reach = Number(row.videoPlayCount || row.videoViewCount || 0);
    const validForEngagementRate = likes > 0 && comments > 0 && reach > 0;
    if ((likes || comments)) {
      posts.push({
        brandId,
        platform: 'instagram',
        likes,
        comments,
        reach,
        totalEngagement: likes + comments,
        engagementRate: validForEngagementRate ? (likes + comments) / reach : null,
        date: row.timestamp,
        hashtags: row.hashtags || '',
        mentions: row.mentions || '',
      });
    }
  }
  // HASH
  for (const row of readCSV(instaHash)) {
    let likes = 0;
    if (brandId === 1 || brandId === 2) likes = Number(row.likesCount || 0); // M&S: likes from HASH, Next: likes from HASH only
    const comments = Number(row.commentsCount || 0);
    // Reach only from OFFICIAL, so 0 here
    if ((likes || comments)) {
      posts.push({
        brandId,
        platform: 'instagram',
        likes,
        comments,
        reach: 0,
        totalEngagement: likes + comments,
        engagementRate: null,
        date: row.timestamp,
        hashtags: row.hashtags || '',
        mentions: row.mentions || '',
      });
    }
  }

  // --- YOUTUBE (Both official and hashtag files) ---
  const ytFiles = brandId === 1 
    ? ['mands_yt_off.csv', 'mands_yt_hash.csv']
    : ['next_yt_off.csv', 'next_yt_hash.csv'];

  for (const file of ytFiles) {
    for (const row of readCSV(file)) {
    const likes = Number(row.likes || 0);
    const comments = Number(row.commentsCount || 0);
    const reach = Number(row.viewCount || 0);
    const validForEngagementRate = likes > 0 && comments > 0 && reach > 0;
    if ((likes || comments)) {
      posts.push({
        brandId,
        platform: 'youtube',
        likes,
        comments,
        reach,
        totalEngagement: likes + comments,
        engagementRate: validForEngagementRate ? (likes + comments) / reach : null,
        date: row.date,
        hashtags: row.hashtags || '',
        mentions: '', // always zero for YouTube
      });
      }
    }
  }
  return posts;
}

function extractTopics(text: string): string[] {
  // Extract hashtags and split text into words (improve as needed)
  const hashtags = (text.match(/#\w+/g) || []).map(tag => tag.toLowerCase());
  const words = text
    .replace(/[^a-zA-Z0-9# ]/g, '')
    .toLowerCase()
    .split(' ')
    .filter(word => word.length > 4 && !word.startsWith('#'));
  return [...hashtags, ...words];
}

async function analyzeSentimentWithTextBlob(text: string) {
  if (!text || typeof text !== 'string') return { sentiment: 'neutral', score: 0.5 };
  try {
    const response = await fetch('http://localhost:5001/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    if (!response.ok) return { sentiment: 'neutral', score: 0.5 };
    return await response.json();
  } catch (error) {
    console.error('TextBlob API error:', error);
    return { sentiment: 'neutral', score: 0.5 };
  }
}

export async function getKeyTopicsBySentiment(brandId: number, platform?: string) {
  const files = [
    brandId === 1 ? 'mands_insta_off.csv' : 'next_insta_off.csv',
    brandId === 1 ? 'mands_tik_off.csv' : 'next_tik_off.csv',
    brandId === 1 ? 'mands_yt_off.csv' : 'next_yt_off.csv'
  ];
  const topicSentimentMap: Record<string, { positive: number; neutral: number; negative: number }> = {};

  for (const file of files) {
    for (const row of readCSV(file)) {
      let text = '';
      if (file.includes('insta')) {
        text = row.caption || '';
      } else if (file.includes('tik')) {
        text = row.description || row.video_description || row.text || '';
      } else if (file.includes('yt')) {
        text = row.title || row.video_description || '';
      }
      const { sentiment } = await analyzeSentimentWithTextBlob(text);
      const topics = extractTopics(text);
      for (const topic of topics) {
        if (!topicSentimentMap[topic]) {
          topicSentimentMap[topic] = { positive: 0, neutral: 0, negative: 0 };
        }
        if (sentiment === 'positive' || sentiment === 'neutral' || sentiment === 'negative') {
          topicSentimentMap[topic][sentiment as 'positive' | 'neutral' | 'negative']++;
        }
      }
    }
  }
  return topicSentimentMap;
}

export async function getPostFrequency(brandId: number, platform?: string, startDate?: string, endDate?: string) {
  const posts = aggregatePosts(brandId);
  
  // Filter by platform if specified
  let filteredPosts = posts;
  if (platform) {
    filteredPosts = posts.filter(post => post.platform === platform.toLowerCase());
  }
  
  // Filter by date range if specified
  if (startDate || endDate) {
    filteredPosts = filteredPosts.filter(post => isWithinDateRange(post.date, startDate, endDate));
  }
  
  // Group posts by date
  const frequencyMap: Record<string, number> = {};
  filteredPosts.forEach(post => {
    const date = post.date.split('T')[0]; // Get just the date part
    frequencyMap[date] = (frequencyMap[date] || 0) + 1;
  });
  
  // Convert to array format
  return Object.entries(frequencyMap).map(([date, count]) => ({
    date,
    count
  })).sort((a, b) => a.date.localeCompare(b.date));
}

export const storage = {
  // Example: getBrands returns static brands based on available CSVs
  async getBrands(): Promise<any[]> {
    // You can hardcode or infer from CSV filenames
    return [
      { id: 1, name: 'Marks & Spencer', slug: 'marks-spencer', industry: 'Retail', description: 'Marks & Spencer', createdAt: new Date() },
      { id: 2, name: 'Next Retail', slug: 'next-retail', industry: 'Retail', description: 'Next Retail', createdAt: new Date() },
    ];
  },

  async getBrandBySlug(slug: string): Promise<any> {
    const brands = await this.getBrands();
    return brands.find(b => b.slug === slug);
  },

  async getSocialMetrics(brandId: number, startDate?: string, endDate?: string, platform?: string): Promise<any[]> {
    // Read data from the actual CSV files in public folder
      if (brandId === 1) { // Marks & Spencer
      if (!platform || platform === 'all') {
        // Aggregate all platforms data for Marks & Spencer
        let tiktokOfficial = readCSV('mands_tik_off.csv');
        let tiktokHashtag = readCSV('mands_tik_hash.csv');
        let allTiktok = [...tiktokOfficial, ...tiktokHashtag];
        if (startDate || endDate) {
          allTiktok = allTiktok.filter(row => isWithinDateRange(row.created_time, startDate, endDate));
        }

        let instagramOfficial = readCSV('mands_insta_off.csv');
        let instagramHashtag = readCSV('mands_insta_hash.csv');
        let allInstagram = [...instagramOfficial, ...instagramHashtag];
        if (startDate || endDate) {
          allInstagram = allInstagram.filter(row => isWithinDateRange(row.timestamp, startDate, endDate));
        }

        let youtubeOfficial = readCSV('mands_yt_off.csv');
        let youtubeHashtag = readCSV('mands_yt_hash.csv');
        let allYoutube = [...youtubeOfficial, ...youtubeHashtag];
        if (startDate || endDate) {
          allYoutube = allYoutube.filter(row => isWithinDateRange(row.date, startDate, endDate));
        }

        // Calculate aggregated totals
        const totalPosts = allTiktok.length + allInstagram.length + allYoutube.length;
        // For TikTok, engagement is likes + comments (no shares)
        const tiktokLikes = allTiktok.reduce((a, b) => a + Number(b.diggCount || 0), 0);
        const tiktokComments = allTiktok.reduce((a, b) => a + Number(b.commentCount || 0), 0);
        const tiktokShares = allTiktok.reduce((a, b) => a + Number(b.shareCount || 0), 0); // still used for shares field
        const instagramLikes = allInstagram.reduce((a, b) => a + Number(b.likesCount || 0), 0);
        const instagramComments = allInstagram.reduce((a, b) => a + Number(b.commentsCount || 0), 0);
        const youtubeLikes = allYoutube.reduce((a, b) => a + Number(b.likes || 0), 0);
        const youtubeComments = allYoutube.reduce((a, b) => a + Number(b.commentsCount || 0), 0);
        const youtubeViews = allYoutube.reduce((a, b) => a + Number(b.viewCount || 0), 0);
        const totalLikes = tiktokLikes + instagramLikes + youtubeLikes;
        const totalComments = tiktokComments + instagramComments + youtubeComments;
        const totalShares = tiktokShares; // Only TikTok has shares in this context
        const totalReach = allTiktok.reduce((a, b) => a + Number(b.playCount || 0), 0) +
                          allInstagram.reduce((a, b) => a + Number(b.videoViewCount || 0), 0) +
                          youtubeViews;

        // Calculate aggregated engagement score (for TikTok, only likes + comments)
        const engagementScore = ((tiktokLikes + tiktokComments + instagramLikes + instagramComments + youtubeLikes + youtubeComments) / (totalReach || 1) * 100).toFixed(1) + '%';

        return [{
          id: 1,
          brandId,
          platform: 'all',
          date: new Date().toISOString().split('T')[0],
          totalPosts,
          followers: 0,
          mentions: totalPosts,
          likes: totalLikes,
          shares: totalShares,
          comments: totalComments,
          reach: totalReach,
          engagementScore,
          avgResponseTimeHours: '2',
          createdAt: new Date(),
        }];
      } else if (platform === 'tiktok') {
        let tiktokOfficial = readCSV('mands_tik_off.csv');
        let tiktokHashtag = readCSV('mands_tik_hash.csv');
        let allTiktok = [...tiktokOfficial, ...tiktokHashtag];
        if (startDate || endDate) {
          allTiktok = allTiktok.filter(row => isWithinDateRange(row.created_time, startDate, endDate));
        }
        const tiktokLikes = allTiktok.reduce((a, b) => a + Number(b.diggCount || 0), 0);
        const tiktokComments = allTiktok.reduce((a, b) => a + Number(b.commentCount || 0), 0);
        const tiktokShares = allTiktok.reduce((a, b) => a + Number(b.shareCount || 0), 0); // still used for shares field
        const tiktokReach = allTiktok.reduce((a, b) => a + Number(b.playCount || 0), 0);
        const engagementScore = ((tiktokLikes + tiktokComments) / (tiktokReach || 1) * 100).toFixed(1) + '%';
        return [{
          id: 1,
          brandId,
          platform: 'tiktok',
          date: new Date().toISOString().split('T')[0],
          totalPosts: allTiktok.length,
          followers: 0,
          mentions: allTiktok.length,
          likes: tiktokLikes,
          shares: tiktokShares,
          comments: tiktokComments,
          reach: tiktokReach,
          engagementScore,
          avgResponseTimeHours: '1',
          createdAt: new Date(),
        }];
      } else if (platform === 'instagram') {
        let instagramOfficial = readCSV('mands_insta_off.csv');
        let instagramHashtag = readCSV('mands_insta_hash.csv');
        let allInstagram = [...instagramOfficial, ...instagramHashtag];
        if (startDate || endDate) {
          allInstagram = allInstagram.filter(row => isWithinDateRange(row.timestamp, startDate, endDate));
        }
      return [{
          id: 2,
          brandId,
          platform: 'instagram',
        date: new Date().toISOString().split('T')[0],
          totalPosts: allInstagram.length,
          followers: 0,
          mentions: allInstagram.length,
          likes: allInstagram.reduce((a, b) => a + Number(b.likesCount || 0), 0),
          shares: 0, // Instagram doesn't have shares in the CSV
          comments: allInstagram.reduce((a, b) => a + Number(b.commentsCount || 0), 0),
          reach: allInstagram.reduce((a, b) => a + Number(b.videoViewCount || 0), 0),
          engagementScore: calculateEngagementScore('instagram', allInstagram),
          avgResponseTimeHours: '1',
          createdAt: new Date(),
        }];
      } else if (platform === 'youtube') {
        let youtubeOfficial = readCSV('mands_yt_off.csv');
        let youtubeHashtag = readCSV('mands_yt_hash.csv');
        let allYoutube = [...youtubeOfficial, ...youtubeHashtag];
        if (startDate || endDate) {
          allYoutube = allYoutube.filter(row => isWithinDateRange(row.date, startDate, endDate));
        }
      return [{
        id: 3,
          brandId,
        platform: 'youtube',
        date: new Date().toISOString().split('T')[0],
          totalPosts: allYoutube.length,
          followers: 0,
          mentions: allYoutube.length,
          likes: allYoutube.reduce((a, b) => a + Number(b.likes || 0), 0),
        shares: 0,
          comments: allYoutube.reduce((a, b) => a + Number(b.commentsCount || 0), 0),
          reach: allYoutube.reduce((a, b) => a + Number(b.viewCount || 0), 0),
          engagementScore: calculateEngagementScore('youtube', allYoutube),
        avgResponseTimeHours: '1',
          createdAt: new Date(),
        }];
      }
    } else if (brandId === 2) { // Next Retail
      if (!platform || platform === 'all') {
        // Aggregate all platforms data for Next Retail
        let tiktokOfficial = readCSV('next_tik_off.csv');
        let tiktokHashtag = readCSV('next_tik_hash.csv');
        let allTiktok = [...tiktokOfficial, ...tiktokHashtag];
        if (startDate || endDate) {
          allTiktok = allTiktok.filter(row => isWithinDateRange(row.created_time, startDate, endDate));
        }

        let instagramOfficial = readCSV('next_insta_off.csv');
        let instagramHashtag = readCSV('next_insta_hash.csv');
        let allInstagram = [...instagramOfficial, ...instagramHashtag];
        if (startDate || endDate) {
          allInstagram = allInstagram.filter(row => isWithinDateRange(row.timestamp, startDate, endDate));
        }

        let youtubeOfficial = readCSV('next_yt_off.csv');
        let youtubeHashtag = readCSV('next_yt_hash.csv');
        let allYoutube = [...youtubeOfficial, ...youtubeHashtag];
        if (startDate || endDate) {
          allYoutube = allYoutube.filter(row => isWithinDateRange(row.date, startDate, endDate));
        }

        // Calculate aggregated totals
        const totalPosts = allTiktok.length + allInstagram.length + allYoutube.length;
        // For TikTok, engagement is likes + comments (no shares)
        const tiktokLikes = allTiktok.reduce((a, b) => a + Number(b.diggCount || 0), 0);
        const tiktokComments = allTiktok.reduce((a, b) => a + Number(b.commentCount || 0), 0);
        const tiktokShares = allTiktok.reduce((a, b) => a + Number(b.shareCount || 0), 0); // still used for shares field
        const instagramLikes = allInstagram.reduce((a, b) => a + Number(b.likesCount || 0), 0);
        const instagramComments = allInstagram.reduce((a, b) => a + Number(b.commentsCount || 0), 0);
        const youtubeLikes = allYoutube.reduce((a, b) => a + Number(b.likes || 0), 0);
        const youtubeComments = allYoutube.reduce((a, b) => a + Number(b.commentsCount || 0), 0);
        const totalLikes = tiktokLikes + instagramLikes + youtubeLikes;
        const totalComments = tiktokComments + instagramComments + youtubeComments;
        const totalShares = tiktokShares; // Only TikTok has shares in this context
        const totalReach = allTiktok.reduce((a, b) => a + Number(b.playCount || 0), 0) +
                          allInstagram.reduce((a, b) => a + Number(b.videoViewCount || 0), 0) +
                          allYoutube.reduce((a, b) => a + Number(b.viewCount || 0), 0);

        // Calculate aggregated engagement score (for TikTok, only likes + comments)
        const engagementScore = ((tiktokLikes + tiktokComments + instagramLikes + instagramComments + youtubeLikes + youtubeComments) / (totalReach || 1) * 100).toFixed(1) + '%';

        return [{
          id: 1,
          brandId,
          platform: 'all',
          date: new Date().toISOString().split('T')[0],
          totalPosts,
          followers: 0,
          mentions: totalPosts,
          likes: totalLikes,
          shares: totalShares,
          comments: totalComments,
          reach: totalReach,
          engagementScore,
          avgResponseTimeHours: '2',
          createdAt: new Date(),
        }];
      } else if (platform === 'tiktok') {
        let tiktokOfficial = readCSV('next_tik_off.csv');
        let tiktokHashtag = readCSV('next_tik_hash.csv');
        let allTiktok = [...tiktokOfficial, ...tiktokHashtag];
        if (startDate || endDate) {
          allTiktok = allTiktok.filter(row => isWithinDateRange(row.created_time, startDate, endDate));
        }
      return [{
        id: 1,
          brandId,
        platform: 'tiktok',
        date: new Date().toISOString().split('T')[0],
          totalPosts: allTiktok.length,
        followers: 0,
          mentions: allTiktok.length,
          likes: allTiktok.reduce((a, b) => a + Number(b.diggCount || 0), 0),
          shares: allTiktok.reduce((a, b) => a + Number(b.shareCount || 0), 0),
          comments: allTiktok.reduce((a, b) => a + Number(b.commentCount || 0), 0),
          reach: allTiktok.reduce((a, b) => a + Number(b.playCount || 0), 0),
          engagementScore: calculateEngagementScore('tiktok', allTiktok),
        avgResponseTimeHours: '1',
          createdAt: new Date(),
        }];
      } else if (platform === 'instagram') {
        let instagramOfficial = readCSV('next_insta_off.csv');
        let instagramHashtag = readCSV('next_insta_hash.csv');
        let allInstagram = [...instagramOfficial, ...instagramHashtag];
        if (startDate || endDate) {
          allInstagram = allInstagram.filter(row => isWithinDateRange(row.timestamp, startDate, endDate));
        }
      return [{
        id: 2,
          brandId,
        platform: 'instagram',
        date: new Date().toISOString().split('T')[0],
          totalPosts: allInstagram.length,
        followers: 0,
          mentions: allInstagram.length,
          likes: allInstagram.reduce((a, b) => a + Number(b.likesCount || 0), 0),
        shares: 0,
          comments: allInstagram.reduce((a, b) => a + Number(b.commentsCount || 0), 0),
          reach: allInstagram.reduce((a, b) => a + Number(b.videoViewCount || 0), 0),
          engagementScore: calculateEngagementScore('instagram', allInstagram),
        avgResponseTimeHours: '1',
          createdAt: new Date(),
        }];
      } else if (platform === 'youtube') {
        let youtubeOfficial = readCSV('next_yt_off.csv');
        let youtubeHashtag = readCSV('next_yt_hash.csv');
        let allYoutube = [...youtubeOfficial, ...youtubeHashtag];
        if (startDate || endDate) {
          allYoutube = allYoutube.filter(row => isWithinDateRange(row.date, startDate, endDate));
        }
      return [{
        id: 3,
          brandId,
        platform: 'youtube',
        date: new Date().toISOString().split('T')[0],
          totalPosts: allYoutube.length,
        followers: 0,
          mentions: allYoutube.length,
          likes: allYoutube.reduce((a, b) => a + Number(b.likes || 0), 0),
        shares: 0,
          comments: allYoutube.reduce((a, b) => a + Number(b.commentsCount || 0), 0),
          reach: allYoutube.reduce((a, b) => a + Number(b.viewCount || 0), 0),
          engagementScore: calculateEngagementScore('youtube', allYoutube),
        avgResponseTimeHours: '1',
          createdAt: new Date(),
        }];
      }
    }
    return [];
  },

  async getTopContent(brandId: number, limit: number = 10, platform?: string, startDate?: string, endDate?: string): Promise<any[]> {
    let allContent: any[] = [];
    if (brandId === 1) { // Marks & Spencer
      if (!platform || platform === 'tiktok') {
        const tiktokOfficial = readCSV('mands_tik_off.csv');
        const tiktokHashtag = readCSV('mands_tik_hash.csv');
        let allTiktok = [...tiktokOfficial, ...tiktokHashtag];
        if (startDate || endDate) {
          allTiktok = allTiktok.filter(row => isWithinDateRange(row.created_time, startDate, endDate));
        }
        allContent = allContent.concat(allTiktok.map(row => ({
          brandId,
          platform: 'tiktok',
          content: row.text || '',
          postType: 'video',
          publishedAt: row.created_time || new Date().toISOString(),
          views: Number(row.playCount || 0),
          likes: Number(row.diggCount || 0),
          comments: Number(row.commentCount || 0),
          shares: Number(row.shareCount || 0),
          engagementRate: 0,
          createdAt: new Date(),
        })));
      }
      if (!platform || platform === 'instagram') {
        const instagramOfficial = readCSV('mands_insta_off.csv');
        const instagramHashtag = readCSV('mands_insta_hash.csv');
        let allInstagram = [...instagramOfficial, ...instagramHashtag];
        if (startDate || endDate) {
          allInstagram = allInstagram.filter(row => isWithinDateRange(row.timestamp, startDate, endDate));
        }
        allContent = allContent.concat(allInstagram.map(row => ({
          brandId,
          platform: 'instagram',
          content: row.caption || '',
          postType: 'image',
          publishedAt: row.timestamp || new Date().toISOString(),
          views: Number(row.videoViewCount || 0),
          likes: Number(row.likesCount || 0),
          comments: Number(row.commentsCount || 0),
          shares: 0,
          engagementRate: 0,
          createdAt: new Date(),
        })));
      }
      if (!platform || platform === 'youtube') {
        const youtubeOfficial = readCSV('mands_yt_off.csv');
        const youtubeHashtag = readCSV('mands_yt_hash.csv');
        let allYoutube = [...youtubeOfficial, ...youtubeHashtag];
        if (startDate || endDate) {
          allYoutube = allYoutube.filter(row => isWithinDateRange(row.date, startDate, endDate));
        }
        allContent = allContent.concat(allYoutube.map(row => ({
          brandId,
          platform: 'youtube',
          content: row.video_description || '',
          postType: 'video',
          publishedAt: row.date || new Date().toISOString(),
          views: Number(row.view_count || 0),
          likes: Number(row.likes || 0),
          comments: Number(row.commentsCount || 0),
          shares: 0,
          engagementRate: 0,
          createdAt: new Date(),
        })));
      }
    } else if (brandId === 2) { // Next Retail
      if (!platform || platform === 'tiktok') {
        const tiktokOfficial = readCSV('next_tik_off.csv');
        const tiktokHashtag = readCSV('next_tik_hash.csv');
        let allTiktok = [...tiktokOfficial, ...tiktokHashtag];
        if (startDate || endDate) {
          allTiktok = allTiktok.filter(row => isWithinDateRange(row.created_time, startDate, endDate));
        }
        allContent = allContent.concat(allTiktok.map(row => ({
          brandId,
          platform: 'tiktok',
          content: row.text || '',
          postType: 'video',
          publishedAt: row.created_time || new Date().toISOString(),
          views: Number(row.playCount || 0),
          likes: Number(row.diggCount || 0),
          comments: Number(row.commentCount || 0),
          shares: Number(row.shareCount || 0),
          engagementRate: 0,
          createdAt: new Date(),
        })));
      }
      if (!platform || platform === 'instagram') {
        const instagramOfficial = readCSV('next_insta_off.csv');
        const instagramHashtag = readCSV('next_insta_hash.csv');
        let allInstagram = [...instagramOfficial, ...instagramHashtag];
        if (startDate || endDate) {
          allInstagram = allInstagram.filter(row => isWithinDateRange(row.timestamp, startDate, endDate));
        }
        allContent = allContent.concat(allInstagram.map(row => ({
          brandId,
          platform: 'instagram',
          content: row.caption || '',
          postType: 'image',
          publishedAt: row.timestamp || new Date().toISOString(),
          views: Number(row.videoViewCount || 0),
          likes: Number(row.likesCount || 0),
          comments: Number(row.commentsCount || 0),
          shares: 0,
          engagementRate: 0,
          createdAt: new Date(),
        })));
      }
      if (!platform || platform === 'youtube') {
        let youtubeOfficial = readCSV('next_yt_off.csv');
        let youtubeHashtag = readCSV('next_yt_hash.csv');
        let allYoutube = [...youtubeOfficial, ...youtubeHashtag];
        if (startDate || endDate) {
          allYoutube = allYoutube.filter(row => isWithinDateRange(row.date, startDate, endDate));
        }
        allContent = allContent.concat(allYoutube.map(row => ({
          brandId,
          platform: 'youtube',
          content: row.video_description || '',
          postType: 'video',
          publishedAt: row.date || new Date().toISOString(),
          views: Number(row.viewCount || 0),
          likes: Number(row.likes || 0),
          comments: Number(row.commentsCount || 0),
          shares: 0,
          engagementRate: 0,
          createdAt: new Date(),
        })));
      }
    }
    // Sort by (views + likes + comments + shares) descending
    allContent = allContent.sort((a, b) => ((b.views + b.likes + b.comments + b.shares) - (a.views + a.likes + a.comments + a.shares)));
    // Add id field after sorting
    allContent = allContent.map((row, i) => ({ ...row, id: i + 1 }));
    return allContent.slice(0, limit);
  },

  async getBrandHashtags(brandId: number, limit: number = 10, platform?: string, dateRange?: string): Promise<any[]> {
    const posts = await aggregatePosts(brandId);
    let filteredPosts = posts;

    // Filter by platform if specified
    if (platform && platform !== 'all') {
      filteredPosts = filteredPosts.filter(post => post.platform === platform);
    }

    // Filter by date range if specified
    if (dateRange) {
      const now = new Date();
      let startDate: string;
      
      switch (dateRange) {
        case '7days':
        case '7d':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
          break;
        case '30days':
        case '30d':
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
          break;
        case '90days':
        case '90d':
          startDate = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000).toISOString();
          break;
        default:
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString(); // Default to 30 days
      }
      
      filteredPosts = filteredPosts.filter(post => isWithinDateRange(post.date, startDate, now.toISOString()));
    }

    // Extract and count hashtags
    const hashtagCounts = new Map<string, number>();
    filteredPosts.forEach((post: { hashtags?: string }) => {
      if (post.hashtags) {
        const hashtags = post.hashtags.split(',').map((h: string) => h.trim());
            hashtags.forEach((hashtag: string) => {
              if (hashtag) {
            hashtagCounts.set(hashtag, (hashtagCounts.get(hashtag) || 0) + 1);
              }
            });
          }
        });

    // Convert to array and sort by usage count
    return Array.from(hashtagCounts.entries())
      .map(([hashtag, usageCount], i) => ({
            id: i + 1,
            brandId,
        platform: platform || 'all',
        hashtag,
        usageCount,
            engagementRate: 0,
            createdAt: new Date(),
          }))
          .sort((a, b) => b.usageCount - a.usageCount)
          .slice(0, limit);
  },

  async getIndustryHashtags(): Promise<any[]> {
    // Aggregate hashtags from all hashtag CSVs
    const hashtagFiles = [
      'mands_tik_hash.csv', 'mands_insta_hash.csv',
      'next_tik_hash.csv', 'next_insta_hash.csv'
    ];
    const hashtagCounts: { [key: string]: number } = {};
    for (const file of hashtagFiles) {
      const rows = readCSV(file);
      rows.forEach(row => {
        if (row.hashtags) {
          const hashtags = row.hashtags.split(',').map((h: string) => h.trim());
          hashtags.forEach((hashtag: string) => {
            if (hashtag) {
              hashtagCounts[hashtag] = (hashtagCounts[hashtag] || 0) + 1;
            }
          });
        }
      });
    }
    return Object.entries(hashtagCounts)
      .map(([hashtag, count], i) => ({
        id: i + 1,
        hashtag,
        usageCount: count,
        engagementRate: 0,
        createdAt: new Date(),
      }))
      .sort((a, b) => b.usageCount - a.usageCount)
      .slice(0, 20);
  },

  async getAudienceDemographics(brandId: number, date?: string, platform?: string): Promise<any[]> {
    // Example: read demographics from CSVs if available
    // For now, return empty array as this data might not be in the CSVs
    return [];
  },

  async getSentimentData(brandId: number, startDate?: string, endDate?: string, platform?: string): Promise<SentimentRecord[]> {
    try {
      // Check if we have cached sentiment data from the extraction process
      if (global.sentimentData && global.sentimentData.length > 0) {
        console.log(`Using cached sentiment data (${global.sentimentData.length} records)`);
        
        // Filter by brand ID
        let filteredData = global.sentimentData.filter(item => item.brandId === brandId);
        
        // Filter by platform if specified
        if (platform && platform !== 'all') {
          filteredData = filteredData.filter(item => item.platform === platform);
        }
        
        // Filter by date range if specified
        if (startDate || endDate) {
          filteredData = filteredData.filter(item => 
            isWithinDateRange(item.date.toISOString(), startDate, endDate)
          );
        }
        
        console.log(`Returning ${filteredData.length} filtered sentiment records`);
        return filteredData;
      }
      
      // If no cached data, analyze on-the-fly
      console.log('No cached sentiment data found, analyzing on-the-fly');
      const sentimentData = [];
      const instagramFile = brandId === 1 ? 'mands_insta_off.csv' : 'next_insta_off.csv';
      const tiktokFile = brandId === 1 ? 'mands_tik_off.csv' : 'next_tik_off.csv';
      const youtubeFile = brandId === 1 ? 'mands_yt_off.csv' : 'next_yt_off.csv';
      
      // Instagram
      if (!platform || platform === 'instagram' || platform === 'all') {
        for (const post of readCSV(instagramFile)) {
          const text = post.caption || '';
          if (!text) continue;
          
          const { sentiment, score, subjectivity } = await analyzeSentimentWithTextBlob(text);
          const date = new Date(post.timestamp || Date.now());
          
          if (!isWithinDateRange(post.timestamp, startDate, endDate)) continue;
          
          sentimentData.push({ 
            brandId, 
            platform: 'instagram', 
            sentiment, 
            score, 
            subjectivity: subjectivity || 0.5,
            mentionCount: 1, 
            text: text.substring(0, 100), // Store a snippet of the text
            date, 
            createdAt: date 
          });
        }
      }
      
      // TikTok
      if (!platform || platform === 'tiktok' || platform === 'all') {
        for (const video of readCSV(tiktokFile)) {
          const text = video.description || video.text || '';
          if (!text) continue;
          
          const { sentiment, score, subjectivity } = await analyzeSentimentWithTextBlob(text);
          const date = new Date(video.created_time || Date.now());
          
          if (!isWithinDateRange(video.created_time, startDate, endDate)) continue;
          
          sentimentData.push({ 
            brandId, 
            platform: 'tiktok', 
            sentiment, 
            score, 
            subjectivity: subjectivity || 0.5,
            mentionCount: 1, 
            text: text.substring(0, 100),
            date, 
            createdAt: date 
          });
        }
      }
      
      // YouTube
      if (!platform || platform === 'youtube' || platform === 'all') {
        for (const video of readCSV(youtubeFile)) {
          const text = video.title || video.video_description || '';
          if (!text) continue;
          
          const { sentiment, score, subjectivity } = await analyzeSentimentWithTextBlob(text);
          const date = new Date(video.publishedAt || video.date || Date.now());
          
          if (!isWithinDateRange(video.publishedAt || video.date, startDate, endDate)) continue;
          
          sentimentData.push({ 
            brandId, 
            platform: 'youtube', 
            sentiment, 
            score, 
            subjectivity: subjectivity || 0.5,
            mentionCount: 1, 
            text: text.substring(0, 100),
            date, 
            createdAt: date 
          });
        }
      }
      
      console.log(`Generated ${sentimentData.length} sentiment records on-the-fly`);
      return sentimentData;
    } catch (error) {
      console.error('Error fetching sentiment data:', error);
      return [];
    }
  },

  async getContentStrategy(brandId: number, platform?: string, dateRangeParam?: string): Promise<any> {
    const posts = aggregatePosts(brandId);
    
    // Filter by platform if specified
    let filteredPosts = posts;
    if (platform && platform !== 'all') {
      filteredPosts = posts.filter(post => post.platform === platform.toLowerCase());
    }
    
    // Filter by date range if specified
    if (dateRangeParam && dateRangeParam !== 'all') {
      const now = new Date();
      let startDate: Date;
      
      switch (dateRangeParam) {
        case '7days':
          startDate = new Date(now.setDate(now.getDate() - 7));
          break;
        case '30days':
          startDate = new Date(now.setDate(now.getDate() - 30));
          break;
        case '90days':
          startDate = new Date(now.setDate(now.getDate() - 90));
          break;
        default:
          startDate = new Date(now.setDate(now.getDate() - 30)); // Default to 30 days if undefined
      }
      
      filteredPosts = filteredPosts.filter(post => new Date(post.date) >= startDate);
    }
    
    // Calculate posts per day
    const totalPosts = filteredPosts.length;
    const daysInRange = dateRangeParam === 'all' ? 180 : 
                       dateRangeParam === '7days' ? 7 :
                       dateRangeParam === '30days' ? 30 :
                       dateRangeParam === '90days' ? 90 : 30; // Default to 30 days if undefined
    const postsPerDay = totalPosts / daysInRange;
    
    // Calculate content type distribution
    const contentTypes = filteredPosts.reduce((acc: any, post) => {
      const type = post.platform === 'youtube' ? 'video' : 
                  post.platform === 'instagram' ? 'image' : 'video';
      
      if (!acc[type]) {
        acc[type] = { count: 0, type };
      }
      acc[type].count++;
      return acc;
    }, {});
    
    // Convert to array and calculate percentages
    const contentTypesArray = Object.values(contentTypes).map((type: any) => ({
      type: type.type,
      count: type.count,
      percentage: Math.round((type.count / totalPosts) * 100)
    }));
    
    return {
      postsPerDay: parseFloat(postsPerDay.toFixed(2)),
      totalPosts,
      contentTypes: contentTypesArray
    };
  },

  async getAudienceOverlap(
    brand1Id: number, 
    brand2Id: number, 
    platform?: string, 
    dateRange?: string
  ): Promise<{ overlapPercentage: number; commonHashtags: string[] }> {
    // Get all posts for both brands
    const brand1Posts = aggregatePosts(brand1Id);
    const brand2Posts = aggregatePosts(brand2Id);

    // Filter by platform if specified
    let filteredBrand1Posts = brand1Posts;
    let filteredBrand2Posts = brand2Posts;

    if (platform && platform !== 'all') {
      filteredBrand1Posts = brand1Posts.filter(post => post.platform === platform.toLowerCase());
      filteredBrand2Posts = brand2Posts.filter(post => post.platform === platform.toLowerCase());
    }

    // Filter by date range if specified
    if (dateRange && dateRange !== 'all') {
      const now = new Date();
      let startDate: Date;
      
      switch (dateRange) {
        case '7days':
          startDate = new Date(now.setDate(now.getDate() - 7));
          break;
        case '30days':
          startDate = new Date(now.setDate(now.getDate() - 30));
          break;
        case '90days':
          startDate = new Date(now.setDate(now.getDate() - 90));
          break;
        default:
          startDate = new Date(now.setDate(now.getDate() - 30));
      }

      filteredBrand1Posts = filteredBrand1Posts.filter(post => new Date(post.date) >= startDate);
      filteredBrand2Posts = filteredBrand2Posts.filter(post => new Date(post.date) >= startDate);
    }

    // Extract all unique keywords from both brands
    const brand1Keywords = new Set<string>();
    const brand2Keywords = new Set<string>();

    // Process brand 1 posts
    filteredBrand1Posts.forEach(post => {
      const text = `${post.hashtags || ''} ${post.mentions || ''}`;
      const keywords = text.toLowerCase().split(/\s+/).filter(word => word.length > 0);
      keywords.forEach(keyword => brand1Keywords.add(keyword));
    });

    // Process brand 2 posts
    filteredBrand2Posts.forEach(post => {
      const text = `${post.hashtags || ''} ${post.mentions || ''}`;
      const keywords = text.toLowerCase().split(/\s+/).filter(word => word.length > 0);
      keywords.forEach(keyword => brand2Keywords.add(keyword));
    });

    // Find common keywords
    const commonKeywords = new Set<string>();
    brand1Keywords.forEach(keyword => {
      if (brand2Keywords.has(keyword)) {
        commonKeywords.add(keyword);
      }
    });

    // Calculate overlap percentage
    const totalUniqueKeywords = brand1Keywords.size + brand2Keywords.size - commonKeywords.size;
    const overlapPercentage = totalUniqueKeywords > 0 
      ? Math.round((commonKeywords.size / totalUniqueKeywords) * 100)
      : 0;

    // Get top 5 most common keywords
    const commonHashtags = Array.from(commonKeywords)
      .filter(keyword => keyword.startsWith('#'))
      .slice(0, 5);

    return {
      overlapPercentage,
      commonHashtags
    };
  },
};